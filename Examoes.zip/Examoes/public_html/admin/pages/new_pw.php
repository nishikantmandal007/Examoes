<?php

include '../includes/check_user.php';
include '../../database/config.php';

$new_password = ($_POST['pass3']);

$sql = "UPDATE tbl_teacher SET login='$new_password' WHERE teacher_id='$myid'";

if ($conn->query($sql) === TRUE) {
	header("location:../profile.php?display=PASSWORD HAS BEEN CHANGED!!!");
} else {
   header("location:../profile.php?display=SOMETHING WENT WRONG!!");
}

$conn->close();
?>
