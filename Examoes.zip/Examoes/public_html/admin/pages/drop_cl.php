<?php
include '../../database/config.php';
$clid = mysqli_real_escape_string($conn, $_GET['id']);  

$sql = "DELETE FROM tbl_classes WHERE class_id='$clid'";

if ($conn->query($sql) == TRUE) {
    header("location:../classes.php?DELETED SUCCESSFULLY");
} else {
    header("location:../classes.php?Something Went Wrong");
}

$conn->close();
?>
