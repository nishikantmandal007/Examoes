<!--Password Update-->
<?php
include '../includes/check_user.php';   // teacher details
include '../../database/config.php';

$new_password = ($_POST['pass3']);  // this password comes from the profile.php page

$sql = "UPDATE tbl_teacher SET login='$new_password' WHERE teacher_id='$mytid'";
// store it into the database 
if ($conn->query($sql) === TRUE) {
   header("location:../profile.php?rp=PASSWORD HAS BEEN CHANGED!!!");
   // if the query execute successfully then this msg will occur in the url
} else {
   header("location:../profile.php?rp=SOMETHING WENT WRONG!!!");
}

$conn->close();
?>
