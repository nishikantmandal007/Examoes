<?php
include '../../database/config.php';
$ayrid = mysqli_real_escape_string($conn, $_GET['id']);

$sql = "DELETE FROM tbl_acad WHERE ay_id='$ayrid'";

if ($conn->query($sql) === TRUE) {
    header("location:../acad.php?display=AY DELETED!!!");
} else {
    header("location:../acad.php?display=COULD NOT APPLY SETTINGS!!");
}

$conn->close();
?>
