<?php
include '../../database/config.php';


$sql = "DELETE FROM tbl_notice";

if ($conn->query($sql) === TRUE) {
    header("location:../notice.php?display=AY DELETED!!!");
} else {
    header("location:../notice.php?display=COULD NOT APPLY SETTINGS!!");
}

$conn->close();
?>
