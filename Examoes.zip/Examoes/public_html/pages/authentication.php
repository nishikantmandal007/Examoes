<!--this page is responsible for login access, both student and admin section-->
<?php
include '../database/config.php';
$myusername = mysqli_real_escape_string($conn, $_POST['user']);
$mypassword = ($_POST['login']);

$sql = "SELECT * FROM tbl_teacher WHERE teacher_id = '$myusername' AND login = '$mypassword' OR email = '$myusername' AND login = '$mypassword' ";
$result = $conn->query($sql);

if ($result->num_rows > 0) {

    while($row = $result->fetch_assoc()) {
    session_start();
	$_SESSION['login'] = true;
	$_SESSION['first_name'] = $row['first_name'];
	$_SESSION['last_name'] = $row['last_name'];
	$_SESSION['gender'] = $row['gender'];
	$_SESSION['dob'] = $row['dob'];
	$_SESSION['address'] = $row['address'];
	$_SESSION['email'] = $row['email'];
	$_SESSION['phone'] = $row['phone'];
	$_SESSION['ay'] = $row['ay'];
	$_SESSION['role'] = $row['role'];
	$_SESSION['myid'] = $row['teacher_id'];
	$_SESSION['myclass'] = $row['class'];
	$accstat = $row['acc_stat'];	// this means admin or student (default value will be 1)
	if ($accstat == "0") {	// if the value of accstat is 0 then this will execute
	 header("location:../?display=YOUR ACCOUNT HAS BEEN DISABLED!!");	
	}else{	// otherwise redirect to the main page, if you are a student, or admin
		$location = strtolower($row['role']);
	header("location:../$location/");	
	}

    }
} else {	// if the credential does not match then this will occur
    header("location:../login.php?display=WRONG ID AND PASSWORD!!");
}
$conn->close();

?>