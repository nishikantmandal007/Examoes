<?php
include '../../database/config.php';

/*$exid = mysqli_real_escape_string($conn, $_GET['id']);*/
$class = $_GET['cn'];
$class = mysqli_real_escape_string($conn, $_GET['cn']);


$sql = "UPDATE tbl_assessment_records SET rstatus='Result not published' WHERE class='$class'";


if ($conn->query($sql) === TRUE) {
    header("location:../classresults.php?display=Result is Unpublished!!");
} else {
    header("location:../classresults.php?display=Something Went Wrong!!");
}

$conn->close();
?>
