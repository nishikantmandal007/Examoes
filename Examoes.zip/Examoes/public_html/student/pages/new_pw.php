<!--Password Update-->
<?php
include '../includes/check_user.php'; 
include '../../database/config.php';

$new_password = ($_POST['pass1']);  

$sql = "UPDATE tbl_users SET login='$new_password' WHERE user_id='$myid'";
// store it into the database 
if ($conn->query($sql) === TRUE) {
   header("location:../profile.php?display=PASSWORD HAS BEEN CHANGED!!!");
   // if the query execute successfully then this msg will occur in the url
} else {
   header("location:../profile.php?display=SOMETHING WENT WRONG!!!");
}

$conn->close();
?>
