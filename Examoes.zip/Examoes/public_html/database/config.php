<?php
error_reporting(0);
$servername = "localhost";
$username = "u933794386_examoes";
$password = "Nishi@koushik799";
$dbname = "u933794386_sjs_exam";


$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
die("<h2>Database Connection Failure : " . $conn->connect_error . "</h2><hr>");
} 
?>