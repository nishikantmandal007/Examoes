<?php
// TEACHER DROP
include '../../database/config.php';
$tdid = mysqli_real_escape_string($conn, $_GET['tid']);  // fetch the teacher id (changed my ks)

$sql = "DELETE FROM tbl_teacher WHERE teacher_id='$tdid'";

if ($conn->query($sql) === TRUE) {
    header("location:../teacher.php?DELETED SUCCESSFULLY!!");
} else {
    header("location:../teacher.php?Could Not Apply Settings!!!");
}

$conn->close();
?>
