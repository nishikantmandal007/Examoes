<?php
// TEACHER DELETE
include '../../database/config.php';
$tdid = mysqli_real_escape_string($conn, $_GET['id']);  // (ID changed by KOUSHIK)

$sql = "DELETE FROM tbl_teacher WHERE teacher_id='$tdid'";

if ($conn->query($sql) === TRUE) {
    header("location:../teacher.php?DELETED SUCCESSFULLY");
} else {
    header("location:../teacher.php?Could Not Apply Settings");
}

$conn->close();
?>
